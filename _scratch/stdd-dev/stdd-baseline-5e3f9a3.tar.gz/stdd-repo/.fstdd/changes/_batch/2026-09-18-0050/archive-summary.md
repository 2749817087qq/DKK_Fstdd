# Batch 2026-09-18-0050 — 归档摘要

**描述:** 回归修复：batch created_at 写 naive 时间戳（改 utc_now_iso）+ 存量 2 个 batch yaml 补 +00:00 + test_evidence_ops PROPOSAL_YAML 硬编码 changes/ 路径归档后失效（改动态解析 changes→archive）

- 闭合时间: 2026-09-18T00:52:42+00:00
- 变更数量: 1
- 批次策略: monthly

## 变更列表

- [2026-09-18T00:52:36+00:00] batch.py created_at 改 utc_now_iso（根因：strftime 丢时区）；存量 3 个 batch yaml 补 +00:00；test_evidence_ops PROPOSAL_YAML 硬编码 changes/ 路径改 changes→archive 动态解析
