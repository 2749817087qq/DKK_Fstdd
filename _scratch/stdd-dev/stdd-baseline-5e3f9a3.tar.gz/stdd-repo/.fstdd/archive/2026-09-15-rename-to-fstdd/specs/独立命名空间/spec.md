# Spec: 独立命名空间

> Change: 2026-09-15-rename-to-fstdd | Auto-generated Human View

## Requirements

### Requirement: 标识替换必须正确且无自匹配产物（对应 SC1、SC4）

#### Scenario: SC-001

- **GIVEN** 替换脚本已对目标文件执行完毕
- **WHEN** 全仓库检索 FFSTDD_ 前缀
- **THEN** 检索结果 SHALL 为 0 处匹配
- **AND** FSTDD_SRC / FSTDD_OUT / FSTDD_PY / FSTDD_CLI 四个环境变量名 SHALL 各出现且拼写完整

#### Scenario: SC-002

- **GIVEN** 替换脚本已执行完毕，排除 upstream/ 与 .git 目录
- **WHEN** 以词边界正则检索独立的 stdd 标识
- **THEN** SHALL 无残留的独立 stdd 标识（skill 名、命令名、项目名均已更名）
- **AND** 非标识用途的 stdd 字样（如第三方 URL、许可证原文）SHALL 被显式记录为例外，不得静默忽略

### Requirement: CLI 在包改名后必须仍然可用（对应 SC2）

#### Scenario: SC-003

- **GIVEN** Python 包目录已由 upstream/stdd/ 改名为 upstream/fstdd/，且所有 import 已同步
- **WHEN** 执行 upstream/bin/fstdd --help
- **THEN** 命令 SHALL 正常退出（退出码 0），且 usage 行显示 fstdd
- **AND** init / new / status 三个子命令 SHALL 均能正常执行

### Requirement: 安装脚本必须生成更名后的 skill（对应 SC3）

#### Scenario: SC-004

- **GIVEN** 使用隔离输出目录（FSTDD_OUT 指向临时路径）执行 install 脚本
- **WHEN** 检查生成结果
- **THEN** SHALL 生成 6 个以 fstdd 为前缀的 skill 目录
- **AND** verify 脚本 SHALL 输出 PASS
- **AND** 隔离目录之外的 skill 目录 SHALL 不被本次测试改动

### Requirement: 数据目录迁移不得丢失历史资产（对应 SC5）

#### Scenario: SC-005

- **GIVEN** 迁移前已对 .fstdd/ 完成 bundle 备份，且存在两个已归档 change
- **WHEN** 将 .fstdd/ 改名为 .fstdd/ 后执行 fstdd status
- **THEN** 命令 SHALL 能正常读取新目录，且两个已归档 change 均可被列出
- **AND** 归档目录下的 test-report.md / proposal.md SHALL 仍可访问

### Requirement: 改名后既有质量防线必须仍然有效（对应 SC6）

#### Scenario: SC-006

- **GIVEN** 改名全部完成且工作区已提交
- **WHEN** 依次执行 verify_eol / verify_skill_standards / verify_workbuddy_skills
- **THEN** 三项校验 SHALL 全部通过
- **AND** 哨兵名 SHALL 已更新为 FSTDD_LOCAL_POLICY_* 且仍能被 verify 识别
