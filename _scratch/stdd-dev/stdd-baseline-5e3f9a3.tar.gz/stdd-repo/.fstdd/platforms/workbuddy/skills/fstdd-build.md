---
name: stdd-build
description: STDD Phase 4: TDD实现 — 按切片执行 RED→GREEN→REFACTOR 循环
version: "2.2"
trigger_keywords: ["stdd-build", "stdd build", "spec-driven", "tdd"]
---
# STDD Phase 4: BUILD — TDD 实现

## 阶段目标

按切片逐一执行 RED → GREEN → REFACTOR，完成所有实现代码和测试代码。

## 前置条件

- Phase 3 已完成（tasks.md + slices.md 已生成）
- `.fstdd.yaml` 中 `phases.slice.status == "completed"`

## 执行模式

**自动迭代，行为取决于所选模式：**

- **普通模式**：仅在遇到阻塞或重大设计偏离时暂停与用户交互。
- **长程模式**：所有偏离和阻塞自动处理并记录，全程不中断。仅在触发降级条件时暂停。

进入本阶段时，先读取 `.fstdd.yaml` 中的 `long_range.mode` 确定当前模式。

## 长程模式运行协议（仅在 `long_range.mode == "full_auto"` 时适用）

1. **无交互原则**：整个阶段内不使用 AskUserQuestion，不等待用户回复
2. **批量执行**：将同一切片的 RED+GREEN+REFACTOR 合并在一轮内完成
3. **自动降级检测**：每步操作后检查是否触发降级条件（连续3次修复失败/通过率<95%/安全问题）
4. **进度汇报**：每个切片完成后输出简短进度（1行），但不等待回复
5. **阶段衔接**：完成后立即自动调用下一阶段 Skill（stdd-verify）
6. **仅降级时暂停**：仅在触发降级条件时才使用 AskUserQuestion 暂停

## 执行流程

### Step 0: 学习开发规范

在开始编码之前，**必须先读取开发规范**：

1. 读取 `.fstdd/config.d/project.yaml` → 获取 `project.language`
2. 读取 `.fstdd/standards/<language>.md`（如 `python.md`）
3. 学习：命名规范、类型注解要求、异步规则、错误处理模式、测试规范

### Step 1: 按切片顺序执行

对 `slices.md` 中的每个切片（或 `tasks.md` 中的每个任务）：

---

#### Step 1.1: RED — 编写测试

1. 从 `test-plan.md` 中找到本切片对应的 TC 案例
2. 将 TC 案例转化为 pytest 测试函数
3. 测试命名：`test_<被测方法>_<场景>_<预期结果>`
4. 测试函数注释中标注 TC-ID
5. 运行测试 → **确认失败（RED）**
6. 如果测试直接通过 → 检查是否已有等价测试，有则跳过 RED 阶段

---

#### Step 1.2: GREEN — 最小实现

1. 写刚好够通过测试的代码
2. **不写超过测试覆盖范围的代码**（不做"顺便"的事）
3. 遵循开发规范（命名、类型注解、异步、错误处理）
4. 运行测试 → **确认通过（GREEN）**
5. 同时运行已有测试 → 确认无回归

---

#### Step 1.3: REFACTOR — 重构

1. 消除重复代码
2. 改善命名（确保名称匹配实际行为）
3. 提取公共逻辑
4. 应用 deep modules 原则（小接口隐藏大复杂度）
5. 应用 deletion test（如果移除这个模块，复杂度是否集中在调用方？如果不是，这个模块不值得存在）
6. 运行测试 → **保持 GREEN**

---

### Step 2: 处理设计偏离

如果在实现过程中发现 spec/design 需要调整：

**小的偏离**（不改变接口和行为语义）：
- 记录到 `pending-adjustments.md`
- 继续执行（两种模式行为一致）

**大的偏离**（改变接口或行为语义）：

*普通模式*：
- 记录到 `pending-adjustments.md`
- **暂停自动迭代，使用 AskUserQuestion 向用户报告**：

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  STDD Phase 4: BUILD — 设计偏离
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠️ 实现过程中发现需要调整设计：

  原始设计：<引用 design.md 或 spec.md 的原文>
  实际需要：<描述需要的调整>
  原因：<为什么需要调整>

  这个调整影响较大，需要你确认。
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

*长程模式*：
- 自动记录到 `pending-adjustments.md`，包含：原始设计引用、实际调整内容、调整原因、影响范围
- 继续执行，不暂停（按预授权 A1 策略）
- 调整将在 Phase 5 的 `design-adjustments.md` 中汇总

**技术阻塞**：

*普通模式*：
- 暂停，使用 AskUserQuestion 向用户报告阻塞情况，询问处理方案

*长程模式*：
- 按预授权 A2 策略处理：
  - `workaround`：尝试绕过方案，记录到 `pending-adjustments.md`
  - `skip_slice`：标记当前切片为待处理，跳过继续后续切片
  - 若无法绕过且无法跳过 → 降级为暂停等待（触发降级条件）

### Step 3: 切片完成

每个切片完成后：
- 标记 tasks.md 中对应任务为 `[x]`
- 进入下一个切片
- **所有切片完成后**：
  - 长程模式（`long_range.mode == "full_auto"`）：**立即在同一轮次内自动调用 `stdd-verify` skill，不等待用户输入**
  - 普通模式：提示用户可进入 Phase 5: VERIFY

## 产出物

- 实现的源代码文件（新增/修改）
- 新增/修改的测试文件
- `pending-adjustments.md`（如有设计偏离）

## 质量检查

每个切片完成后确认：
- [ ] RED：测试先失败
- [ ] GREEN：最小实现通过测试
- [ ] REFACTOR：重构后测试保持绿色
- [ ] 已有测试无回归

## 用户交互规则

| 场景 | 普通模式 | 长程模式 |
|------|---------|---------|
| 切片正常执行 | 自动完成，不中断 | 自动完成，不中断 |
| 切片之间切换 | 自动进入下一个切片 | 自动进入下一个切片 |
| 小设计偏离 | 记录 pending-adjustments，继续 | 记录 pending-adjustments，继续 |
| 大设计偏离 | 暂停，报告用户 | 自动记录并继续（test-report 汇总） |
| 技术阻塞 | 暂停，询问用户 | 尝试绕过/跳过；无法处理时降级暂停 |
| 所有切片完成 | 自动进入 Phase 5 | 自动进入 Phase 5 |

## 下一阶段

Phase 4 完成 → 自动进入 Phase 5: VERIFY（质量验证）
