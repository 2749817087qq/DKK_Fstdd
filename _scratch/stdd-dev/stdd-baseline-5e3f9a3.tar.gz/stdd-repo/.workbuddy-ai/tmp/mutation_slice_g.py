"""Slice G 变异测试：验证凭证扫描判据真的能捕获。

每个变异：写入一个 intent-to-add 的临时文件 -> 跑测试 -> 必须变红 -> 立即清理并校验。
（M7 的教训：恢复必须每个变异后立即做，不能只放最外层 finally。）
"""
import subprocess
import sys
from pathlib import Path

ROOT = Path(r"D:/tools/FSTDD/stdd-repo")
TEST = "tests/test_mirror_alert_ops.py"
MUTANT_REL = "zz_mutant_cred_probe.txt"
MUTANT = ROOT / MUTANT_REL

PY = r"C:/Python311/python.exe"

# 完整假 PEM：BEGIN/END 成对 + 主体远超 128 字符
FAKE_PEM = (
    "-----BEGIN RSA PRIVATE KEY-----\n"
    + ("MIIEowIBAAKCAQEAxYz" * 12)
    + "\n-----END RSA PRIVATE KEY-----\n"
)

MUTATIONS = [
    ("MG0-baseline", None),
    ("MG1-full-pem", FAKE_PEM),
    ("MG2-ghp", "token = ghp_ABCDEFGHIJKLMNOPQRSTUVWX\n"),
    ("MG3-akia", "key = AKIAIOSFODNN7EXAMPLE\n"),
    ("MG4-placeholder-only (must stay GREEN)", "-----BEGIN RSA PRIVATE KEY-----\nMIIEabc\n"),
]


def git(*args):
    return subprocess.run(["git", *args], cwd=str(ROOT),
                          capture_output=True, text=True, encoding="utf-8",
                          errors="replace")


def cleanup():
    if MUTANT.exists():
        MUTANT.unlink()
    git("rm", "--cached", "--force", "--quiet", MUTANT_REL)
    # 校验：不在索引里
    ls = git("ls-files", "--", MUTANT_REL)
    assert MUTANT_REL not in ls.stdout, f"清理失败：{ls.stdout!r}"
    assert not MUTANT.exists(), "临时文件仍在磁盘"


def run_test():
    r = subprocess.run(
        [PY, "-m", "pytest", TEST, "-q", "-k", "credentials"],
        cwd=str(ROOT / "upstream"),
        capture_output=True, text=True, encoding="utf-8", errors="replace",
    )
    return r.returncode, r.stdout


results = []
try:
    for name, content in MUTATIONS:
        cleanup()
        if content is not None:
            MUTANT.write_text(content, encoding="utf-8", newline="")
            add = git("add", "-N", "-f", MUTANT_REL)
            assert add.returncode == 0, add.stderr
            ls = git("ls-files", "--", MUTANT_REL)
            assert MUTANT_REL in ls.stdout, "变异文件未进入索引，测试看不到它"

        rc, out = run_test()
        red = rc != 0
        expect_red = name != "MG0-baseline" and "must stay GREEN" not in name
        ok = (red == expect_red)
        results.append((name, "RED" if red else "GREEN", "OK" if ok else "*** MISMATCH ***"))
        print(f"{name:45s} -> {'RED  ' if red else 'GREEN'}  {'OK' if ok else '*** MISMATCH ***'}")
        if not ok:
            print(out[-1500:])
        cleanup()
finally:
    cleanup()

print("\n--- summary ---")
bad = [r for r in results if r[2] != "OK"]
for r in results:
    print(f"  {r[0]:45s} {r[1]:6s} {r[2]}")
print(f"\ncaptured {len(results) - len(bad) - 1}/{len(results) - 1} mutations")
sys.exit(1 if bad else 0)
