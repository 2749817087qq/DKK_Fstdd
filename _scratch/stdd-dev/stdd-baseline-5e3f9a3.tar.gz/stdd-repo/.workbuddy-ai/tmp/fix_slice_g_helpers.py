"""补回被覆盖的 _BINARY_SUFFIXES / _tracked_files。"""
from pathlib import Path

TARGET = Path(r"D:/tools/FSTDD/stdd-repo/upstream/tests/test_mirror_alert_ops.py")

ANCHOR = "_PEM_MIN_BODY = 128\n"

INSERT = '''
_BINARY_SUFFIXES = {
    ".png", ".jpg", ".jpeg", ".gif", ".ico", ".pdf",
    ".whl", ".zip", ".gz", ".tar", ".exe", ".dll", ".so",
}


def _tracked_files():
    """枚举 git 跟踪的文本文件。二进制按后缀跳过（读进来只会是乱码）。"""
    out = subprocess.run(
        ["git", "ls-files"],
        cwd=str(ROOT),
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    assert out.returncode == 0, out.stderr
    for line in out.stdout.splitlines():
        path = ROOT / line
        if path.is_file() and path.suffix.lower() not in _BINARY_SUFFIXES:
            yield path

'''

src = TARGET.read_text(encoding="utf-8")
assert src.count(ANCHOR) == 1, f"anchor count = {src.count(ANCHOR)}"
assert "_tracked_files" in src
src = src.replace(ANCHOR, ANCHOR + INSERT, 1)
TARGET.write_text(src, encoding="utf-8", newline="")
print("ok, CRLF:", b"\r\n" in TARGET.read_bytes())
