"""探针：逐个模式列出仓库内实际命中，用于校准判据。"""
import re
import subprocess
from pathlib import Path

ROOT = Path(r"D:/tools/FSTDD/stdd-repo")

PATTERNS = (
    ("GitHub PAT (classic)", r"ghp_[A-Za-z0-9]{20,}"),
    ("GitHub PAT (fine-grained)", r"github_pat_[A-Za-z0-9_]{20,}"),
    ("API key (sk- style)", r"sk-[A-Za-z0-9]{20,}"),
    ("AWS access key id", r"AKIA[0-9A-Z]{16}"),
    ("private key begin (naive)", r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
)

BINARY_SUFFIXES = {
    ".png", ".jpg", ".jpeg", ".gif", ".ico", ".pdf",
    ".whl", ".zip", ".gz", ".tar", ".exe", ".dll", ".so",
}

out = subprocess.run(["git", "ls-files"], cwd=str(ROOT),
                     capture_output=True, text=True, encoding="utf-8",
                     errors="replace")
files = [ROOT / l for l in out.stdout.splitlines()]
files = [p for p in files if p.is_file() and p.suffix.lower() not in BINARY_SUFFIXES]
print(f"scanned files: {len(files)}")

for label, pat in PATTERNS:
    print(f"\n=== {label} :: {pat}")
    n = 0
    for path in files:
        text = path.read_text(encoding="utf-8", errors="replace")
        for m in re.finditer(pat, text):
            n += 1
            rel = path.relative_to(ROOT)
            line_no = text[: m.start()].count("\n") + 1
            print(f"  {rel}:{line_no}  ->  {m.group(0)[:40]!r}")
    print(f"  total={n}")

# 检查占位样本的实际结构
print("\n=== placeholder structure in test_inbox_endpoint.py ===")
p = ROOT / "upstream/tests/test_inbox_endpoint.py"
t = p.read_text(encoding="utf-8", errors="replace")
for m in re.finditer(r"-----BEGIN [A-Z ]*PRIVATE KEY-----", t):
    seg = t[m.start(): m.start() + 220]
    print(repr(seg))
    print("-" * 60)
