"""Slice G 收尾：重写凭证扫描块。

三处修正：
1. 私钥判据改为「BEGIN/END 成对 + 主体 >= 128 字符」—— 基于内容而非路径白名单，
   既存夹具（孤立占位串）自动不命中，真实私钥仍必命中。
2. 命中报告只含「文件:行号 + 模式名」，不含匹配内容（原实现打印前 12 字符 = 日志泄露凭证）。
3. 增加下界断言，防止 git ls-files 异常返回空导致测试空过。
"""
from pathlib import Path

TARGET = Path(r"D:/tools/FSTDD/stdd-repo/upstream/tests/test_mirror_alert_ops.py")

OLD_START = '_CREDENTIAL_PATTERNS = ('
OLD_END = '    assert not hits, "仓库内发现凭证：\\n" + "\\n".join(hits)\n'

NEW_BLOCK = '''_CREDENTIAL_PATTERNS = (
    ("GitHub PAT (classic)", r"ghp_[A-Za-z0-9]{20,}"),
    ("GitHub PAT (fine-grained)", r"github_pat_[A-Za-z0-9_]{20,}"),
    ("API key (sk- style)", r"sk-[A-Za-z0-9]{20,}"),
    ("AWS access key id", r"AKIA[0-9A-Z]{16}"),
    ("Slack token", r"xox[baprs]-[A-Za-z0-9-]{10,}"),
    ("Google API key", r"AIza[0-9A-Za-z_-]{35}"),
)

# 私钥单独判据：必须 BEGIN/END 成对且主体足够长，才算真实私钥。
#
# 为什么不能只用 `-----BEGIN ... PRIVATE KEY-----` 这个裸模式：
# `upstream/tests/test_inbox_endpoint.py` 里有既存夹具，用私钥标记作为
# **被测输入**，验证 8787 端点会拒绝含私钥的内容。那是占位串（无 END 配对、
# 主体是占位字符），不是凭证。
#
# 用「成对 + 主体长度」判据区分，而不是把该文件加进白名单 ——
# 白名单会同时放走「有人真的把私钥粘进测试文件」这种情况；
# 内容判据不会：真实 RSA/EC 私钥主体远超 128 字符，占位串远远达不到。
_PEM_PAIR = re.compile(
    r"-----BEGIN ([A-Z ]*PRIVATE KEY)-----(.*?)-----END \\1-----",
    re.S,
)
_PEM_MIN_BODY = 128


def _scan_credentials(files):
    """返回命中位置列表。**只含位置，不含匹配内容** —— 报告凭证片段本身就是泄露。"""
    hits = []
    for path in files:
        text = path.read_text(encoding="utf-8", errors="replace")
        rel = path.relative_to(ROOT)
        for label, pattern in _CREDENTIAL_PATTERNS:
            for match in re.finditer(pattern, text):
                line_no = text[: match.start()].count("\\n") + 1
                hits.append(f"{rel}:{line_no}: {label}")
        for match in _PEM_PAIR.finditer(text):
            body_len = len(re.sub(r"\\s", "", match.group(2)))
            if body_len >= _PEM_MIN_BODY:
                line_no = text[: match.start()].count("\\n") + 1
                hits.append(f"{rel}:{line_no}: private key block (body {body_len} chars)")
    return hits


def test_repo_contains_no_credentials():
    """TC-MFA-023 / SC-017：仓库内不得出现任何凭证。

    服务器是公网机器；本项目已发生过明文凭证进入配置的教训。
    控制面访问只走回环 + SSH 通道，不依赖写入仓库的密钥。

    模式要求**真实字符**（如 `ghp_` 后跟 20+ 位），因此脱敏规则里
    `ghp_[A-Za-z0-9]{20,}` 这类模式定义本身不会命中。
    """
    files = list(_tracked_files())
    # 下界断言：若 git ls-files 失败或 ROOT 解析错，files 会为空 → 测试空过。
    # 仓库当前有 900+ tracked 文本文件，500 是安全下界。
    assert len(files) > 500, f"扫描面异常偏小（{len(files)} 个文件），疑似 git ls-files 未生效"

    hits = _scan_credentials(files)
    assert not hits, "仓库内发现凭证：\\n" + "\\n".join(hits)
'''

src = TARGET.read_text(encoding="utf-8")
start = src.index(OLD_START)
end = src.index(OLD_END) + len(OLD_END)
patched = src[:start] + NEW_BLOCK + src[end:]
TARGET.write_text(patched, encoding="utf-8", newline="")

print("patched bytes:", len(src), "->", len(patched))
print("CRLF present:", b"\r\n" in TARGET.read_bytes())
