"""探针 v2：只输出计数与位置，绝不输出匹配内容（避免日志泄露凭证）。"""
import re
import subprocess
from pathlib import Path

ROOT = Path(r"D:/tools/FSTDD/stdd-repo")

PATTERNS = (
    ("GitHub PAT (classic)", r"ghp_[A-Za-z0-9]{20,}"),
    ("GitHub PAT (fine-grained)", r"github_pat_[A-Za-z0-9_]{20,}"),
    ("API key (sk- style)", r"sk-[A-Za-z0-9]{20,}"),
    ("AWS access key id", r"AKIA[0-9A-Z]{16}"),
    ("private key begin (naive)", r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
)

BINARY_SUFFIXES = {
    ".png", ".jpg", ".jpeg", ".gif", ".ico", ".pdf",
    ".whl", ".zip", ".gz", ".tar", ".exe", ".dll", ".so",
}

out = subprocess.run(["git", "ls-files"], cwd=str(ROOT),
                     capture_output=True, text=True, encoding="utf-8",
                     errors="replace")
files = [ROOT / l for l in out.stdout.splitlines()]
files = [p for p in files if p.is_file() and p.suffix.lower() not in BINARY_SUFFIXES]
print(f"scanned files: {len(files)}")

for label, pat in PATTERNS:
    locs = []
    for path in files:
        text = path.read_text(encoding="utf-8", errors="replace")
        for m in re.finditer(pat, text):
            line_no = text[: m.start()].count("\n") + 1
            locs.append(f"{path.relative_to(ROOT)}:{line_no}")
    print(f"\n=== {label} :: total={len(locs)}")
    for loc in locs[:20]:
        print(f"    {loc}")
    if len(locs) > 20:
        print(f"    ... (+{len(locs) - 20} more)")

# 占位样本结构（只报形状，不报内容）
print("\n=== placeholder shape (len only) ===")
p = ROOT / "upstream/tests/test_inbox_endpoint.py"
t = p.read_text(encoding="utf-8", errors="replace")
for m in re.finditer(r"-----BEGIN [A-Z ]*PRIVATE KEY-----", t):
    seg = t[m.start(): m.start() + 400]
    has_end = "-----END" in seg
    body = seg.split("-----", 2)[-1] if seg.count("-----") >= 3 else ""
    body_nospace = re.sub(r"\s", "", body)
    print(f"    has_END={has_end}  body_len_nospace={len(body_nospace)}")

# 真实 PEM 判据试算：成对 + 主体 >= 128
PAIR = re.compile(r"-----BEGIN ([A-Z ]*PRIVATE KEY)-----(.*?)-----END \1-----", re.S)
print("\n=== paired-PEM judgement ===")
tot = 0
for path in files:
    text = path.read_text(encoding="utf-8", errors="replace")
    for m in PAIR.finditer(text):
        body = re.sub(r"\s", "", m.group(2))
        if len(body) >= 128:
            tot += 1
            print(f"    HIT {path.relative_to(ROOT)}  body={len(body)}")
print(f"    total hits = {tot}")
